
  # Redesign Incident Detail View

  This is a code bundle for Redesign Incident Detail View. The original project is available at https://www.figma.com/design/N1C6PwZAKopYYUoAB2gRMz/Redesign-Incident-Detail-View.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  