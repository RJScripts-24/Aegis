import { motion } from "motion/react";
import { AlertTriangle } from "lucide-react";

export function AlertTicker() {
  const alerts = [
    "⚠️ Zone 3 residents advised to move to safe zones",
    "Emergency Services: All units responding to downtown area",
    "Critical: Highway 101 closed due to flooding",
    "Shelter locations now available - Check map for details",
  ];

  const alertText = alerts.join("     •     ");
  const repeatedText = `${alertText}     •     ${alertText}     •     ${alertText}`;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#1A1A1A]/95 backdrop-blur-md border-t border-white/10 overflow-hidden">
      <div className="py-3 px-4">
        <motion.div
          className="text-[#9CA3AF] whitespace-nowrap flex items-center gap-2"
          animate={{
            x: [0, -1200],
          }}
          transition={{
            duration: 40,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          <AlertTriangle className="w-4 h-4 text-[#F59E0B] flex-shrink-0" />
          <span>{repeatedText}</span>
        </motion.div>
      </div>
    </div>
  );
}
