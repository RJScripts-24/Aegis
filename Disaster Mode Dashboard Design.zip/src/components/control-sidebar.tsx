import { useState } from "react";
import { motion } from "motion/react";
import { Layers, AlertCircle, FileText, Cross, Home, Clock } from "lucide-react";
import { Checkbox } from "./ui/checkbox";
import { Button } from "./ui/button";

export function ControlSidebar() {
  const [layers, setLayers] = useState({
    alerts: true,
    reports: true,
    resources: false,
    shelters: false,
    timeFilter: false,
  });

  const toggleLayer = (key: keyof typeof layers) => {
    setLayers((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const layerItems = [
    { id: "alerts", label: "Alerts", icon: AlertCircle, color: "text-[#EF4444]" },
    { id: "reports", label: "Reports", icon: FileText, color: "text-[#5A67D8]" },
    { id: "resources", label: "Resources", icon: Cross, color: "text-[#9CA3AF]" },
    { id: "shelters", label: "Shelters", icon: Home, color: "text-[#9CA3AF]" },
    { id: "timeFilter", label: "Filter by Time", icon: Clock, color: "text-[#9CA3AF]" },
  ];

  return (
    <div className="h-full flex flex-col gap-6 pb-4">
      {/* Map Layers Module */}
      <div className="bg-[#2C2C2C] rounded-lg p-6 border border-white/10 flex-shrink-0">
      <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[#5A67D8] flex items-center justify-center">
            <Layers className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-white">Map Layers</h2>
            <p className="text-sm text-[#9CA3AF]">Toggle visibility</p>
          </div>
        </div>
        
        <div className="flex flex-col gap-4">
          {layerItems.map((item) => {
            const Icon = item.icon;
            const isChecked = layers[item.id as keyof typeof layers];
            return (
              <div
                key={item.id}
                className={`flex items-center gap-3 cursor-pointer px-3 py-2 rounded-lg transition-all duration-200 ${
                  isChecked 
                    ? 'bg-gradient-to-r from-[#5A67D8]/20 to-transparent hover:from-[#5A67D8]/30 hover:to-[#5A67D8]/10' 
                    : 'hover:bg-gradient-to-r hover:from-white/5 hover:to-transparent'
                }`}
                onClick={() => toggleLayer(item.id as keyof typeof layers)}
              >
                <Checkbox
                  checked={isChecked}
                  className={isChecked ? "border-[#5A67D8] data-[state=checked]:bg-[#5A67D8]" : "border-white/20"}
                />
                <Icon className={`w-5 h-5 ${isChecked ? item.color : 'text-[#4A5568]'}`} strokeWidth={1.5} />
                <span className={isChecked ? "text-white" : "text-[#9CA3AF]"}>{item.label}</span>
              </div>
            );
          })}
        </div>
        
        <p className="text-sm text-[#9CA3AF] mt-6">
          Select layers to customize your map view and filter information based on your needs.
        </p>
      </div>

      {/* Emergency Resources Module */}
      <div className="bg-[#2C2C2C] rounded-lg p-6 border border-white/10 flex-shrink-0">
        <h2 className="text-white mb-2">Emergency Resources</h2>
        <p className="text-sm text-[#9CA3AF] mb-6">
          Access emergency services, evacuation routes, and real-time disaster updates.
        </p>
        
        <div className="flex flex-col gap-3">
          <Button
            className="w-full bg-[#5A67D8] text-white hover:bg-[#5A67D8]/90 justify-start px-4 transition-all"
          >
            Emergency Contacts
          </Button>
          
          <Button
            variant="outline"
            className="w-full border-white/20 text-white hover:bg-white/5 justify-start px-4 transition-all"
          >
            View Guide
          </Button>
        </div>
      </div>
    </div>
  );
}
