import { motion } from "motion/react";
import { Camera, CheckCircle } from "lucide-react";
import { Button } from "./ui/button";

export function ActionButtons() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      className="absolute bottom-6 left-6 right-6 flex items-center justify-between gap-4 z-10"
    >
      <Button
        className="flex-1 bg-[#2C2C2C] text-white hover:bg-[#3D3D4F] border border-white/20 shadow-lg py-6 gap-2 transition-all"
      >
        <Camera className="w-5 h-5" />
        Report an Incident
      </Button>
      
      <Button
        className="flex-1 bg-[#22C55E] text-white hover:bg-[#22C55E]/90 shadow-lg py-6 gap-2 transition-all"
        style={{
          boxShadow: "0 4px 14px 0 rgba(34, 197, 94, 0.39)",
        }}
      >
        <CheckCircle className="w-5 h-5" />
        I Am Safe
      </Button>
    </motion.div>
  );
}
