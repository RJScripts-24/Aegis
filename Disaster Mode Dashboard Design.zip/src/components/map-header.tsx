import { Shield } from "lucide-react";

export function MapHeader() {
  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-[#1A1A1A]/95 backdrop-blur-md border-b border-white/10">
      <div className="px-6 py-4 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-[#5A67D8] flex items-center justify-center">
          <Shield className="w-5 h-5 text-white" />
        </div>
        <span className="text-white tracking-wide">AEGIS DISASTER MODE</span>
      </div>
    </div>
  );
}
