import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { MapControls } from "./map-controls";

interface DisasterMapProps {
  isScrolled: boolean;
}

export function DisasterMap({ isScrolled }: DisasterMapProps) {
  const markers = [
    { id: 1, type: "alert", x: "28%", y: "28%", color: "#EF4444", label: "High Risk" },
    { id: 2, type: "alert", x: "62%", y: "22%", color: "#EF4444", label: "Flood Warning" },
    { id: 3, type: "alert", x: "55%", y: "68%", color: "#EF4444", label: "Evacuation" },
    { id: 4, type: "warning", x: "48%", y: "45%", color: "#F59E0B", label: "Moderate Risk" },
    { id: 5, type: "warning", x: "58%", y: "82%", color: "#F59E0B", label: "Caution" },
  ];

  return (
    <div className="relative h-full bg-[#2C2C2C] rounded-lg overflow-hidden border border-white/10">
      {/* Map Background */}
      <div className="absolute inset-0 opacity-70">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1722082839841-45473f5a15cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXRlbGxpdGUlMjBjaXR5JTIwbWFwJTIwYWVyaWFsfGVufDF8fHx8MTc2MTMwMjA2MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Satellite city map"
          className="w-full h-full object-cover grayscale-[30%]"
        />
      </div>

      {/* Map Controls */}
      <MapControls />

      {/* Alert Markers */}
      {markers.map((marker) => (
        <div
          key={marker.id}
          className="absolute"
          style={{ left: marker.x, top: marker.y }}
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3 + marker.id * 0.1, type: "spring" }}
            className="relative"
          >
            {/* Pulsing ring */}
            <motion.div
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.5, 0, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeOut",
              }}
              className="absolute -inset-3 rounded-full border-2"
              style={{ borderColor: marker.color }}
            />
            
            {/* Marker dot */}
            <div
              className="relative w-8 h-8 rounded-full border-3 border-white shadow-lg flex items-center justify-center cursor-pointer hover:scale-110 transition-transform"
              style={{ backgroundColor: marker.color }}
            >
              <div className="w-2 h-2 rounded-full bg-white" />
            </div>
          </motion.div>
        </div>
      ))}

      {/* Your Location Indicator with Blue Pulse Effect */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        {/* Outer pulse */}
        <motion.div
          animate={{
            scale: [1, 2.5, 1],
            opacity: [0.3, 0, 0.3],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeOut",
          }}
          className="absolute -inset-16 rounded-full bg-[#3B82F6]/40"
        />
        
        {/* Middle pulse */}
        <motion.div
          animate={{
            scale: [1, 2, 1],
            opacity: [0.4, 0, 0.4],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeOut",
            delay: 0.3,
          }}
          className="absolute -inset-12 rounded-full bg-[#3B82F6]/50"
        />
        
        {/* Inner glow */}
        <div className="absolute -inset-6 rounded-full bg-[#3B82F6]/30 blur-xl" />
        
        {/* Location marker */}
        <div className="relative w-4 h-4 rounded-full bg-[#3B82F6] border-4 border-white shadow-lg" />
        
        {/* Location label */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="absolute top-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-[#2C2C2C] border border-white/20 px-4 py-2 rounded-full shadow-lg text-white text-sm"
        >
          Your Location
        </motion.div>
      </div>

      {/* Scroll indicator on initial view */}
      {!isScrolled && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="absolute bottom-6 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-8 h-12 rounded-full border-2 border-white/40 flex items-start justify-center pt-2 bg-[#2C2C2C]/50 backdrop-blur-sm"
          >
            <div className="w-1 h-2 bg-white/90 rounded-full" />
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
