import { Plus, Minus, Layers } from "lucide-react";
import { Button } from "./ui/button";

export function MapControls() {
  return (
    <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
      <Button
        size="icon"
        variant="secondary"
        className="w-10 h-10 bg-[#2C2C2C] hover:bg-[#3D3D4F] border border-white/10 shadow-md rounded-lg transition-all"
      >
        <Layers className="w-5 h-5 text-[#E0E0E0]" />
      </Button>
      
      <Button
        size="icon"
        variant="secondary"
        className="w-10 h-10 bg-[#2C2C2C] hover:bg-[#3D3D4F] border border-white/10 shadow-md rounded-lg transition-all"
      >
        <Plus className="w-5 h-5 text-[#E0E0E0]" />
      </Button>
      
      <Button
        size="icon"
        variant="secondary"
        className="w-10 h-10 bg-[#2C2C2C] hover:bg-[#3D3D4F] border border-white/10 shadow-md rounded-lg transition-all"
      >
        <Minus className="w-5 h-5 text-[#E0E0E0]" />
      </Button>
    </div>
  );
}
