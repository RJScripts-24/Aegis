import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { MapHeader } from "./components/map-header";
import { AlertTicker } from "./components/alert-ticker";
import { ControlSidebar } from "./components/control-sidebar";
import { DisasterMap } from "./components/disaster-map";
import { ActionButtons } from "./components/action-buttons";

export default function App() {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const windowHeight = window.innerHeight;
      // Transition happens between 0 and 1 window height of scrolling
      const progress = Math.min(scrollTop / windowHeight, 1);
      setScrollProgress(progress);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Calculate smooth opacity transitions
  const fullMapOpacity = 1 - scrollProgress;
  const splitViewOpacity = scrollProgress;

  return (
    <div className="min-h-[200vh] bg-[#1A1A1A]">
      {/* Fixed Header */}
      <MapHeader />
      
      {/* Fixed Alert Ticker at Bottom */}
      <AlertTicker />

      {/* Main Content */}
      <div className="pt-[72px] pb-[60px]">
        {/* Sticky container for smooth transitions */}
        <div className="sticky top-[72px] h-[calc(100vh-132px)] overflow-hidden">
          <div className="relative h-full">
            {/* PART 1: Initial Full Map View */}
            <motion.div
              className="absolute inset-0 px-6"
              style={{
                opacity: fullMapOpacity,
                pointerEvents: scrollProgress > 0.5 ? "none" : "auto",
              }}
            >
              <DisasterMap isScrolled={false} />
            </motion.div>

            {/* PART 2: Scrolled View with Sidebar */}
            <motion.div
              className="absolute inset-0 px-6"
              style={{
                opacity: splitViewOpacity,
                pointerEvents: scrollProgress < 0.5 ? "none" : "auto",
              }}
            >
              <div className="max-w-[1600px] mx-auto h-full">
                <div className="grid grid-cols-12 gap-6 h-full">
                  {/* Left Control Sidebar */}
                  <motion.div
                    className="col-span-4 h-full overflow-y-auto"
                    initial={{ x: -50, opacity: 0 }}
                    animate={{
                      x: scrollProgress > 0.3 ? 0 : -50,
                      opacity: scrollProgress > 0.3 ? 1 : 0,
                    }}
                    transition={{ duration: 0.3 }}
                  >
                    {scrollProgress > 0.2 && <ControlSidebar />}
                  </motion.div>

                  {/* Right Map Area with Action Buttons */}
                  <motion.div
                    className="col-span-8 relative h-full"
                    initial={{ x: 50, opacity: 0 }}
                    animate={{
                      x: scrollProgress > 0.3 ? 0 : 50,
                      opacity: scrollProgress > 0.3 ? 1 : 0,
                    }}
                    transition={{ duration: 0.3 }}
                  >
                    {scrollProgress > 0.2 && (
                      <div className="relative h-full">
                        <DisasterMap isScrolled={true} />
                        <ActionButtons />
                      </div>
                    )}
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Spacer for scroll - this creates the scroll distance */}
        <div className="h-[100vh]" />
      </div>
    </div>
  );
}
