
  # Redesign AEGIS Webpage

  This is a code bundle for Redesign AEGIS Webpage. The original project is available at https://www.figma.com/design/TPMWpOu3lhbOLU3NSKzNwa/Redesign-AEGIS-Webpage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  